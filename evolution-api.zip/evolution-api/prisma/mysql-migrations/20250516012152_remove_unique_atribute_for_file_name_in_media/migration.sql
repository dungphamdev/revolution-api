-- DropIndex
ALTER TABLE `Media` DROP INDEX `Media_fileName_key`;
