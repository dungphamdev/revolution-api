-- DropIndex
DROP INDEX "OpenaiCreds_instanceId_key";
