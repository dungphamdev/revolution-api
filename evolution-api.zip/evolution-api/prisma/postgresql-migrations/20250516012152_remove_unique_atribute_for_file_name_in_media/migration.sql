-- DropIndex
DROP INDEX "Media_fileName_key";
