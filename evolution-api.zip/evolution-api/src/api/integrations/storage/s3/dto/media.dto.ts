export class MediaDto {
  id?: string;
  type?: string;
  messageId?: number;
  expiry?: number;
}
